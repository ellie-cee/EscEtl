import paramiko

class SftpClient:
    def __init__(self):
        pass